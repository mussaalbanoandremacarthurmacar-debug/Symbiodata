import { useEffect, useRef, useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { ChevronLeft, Lock, Pause, Play, Radio } from "lucide-react";
import { DnaRibbon } from "@/components/DnaRibbon";
import { EcgCanvas } from "@/components/EcgCanvas";
import { HoldLeaf } from "@/components/HoldLeaf";
import { KindChip } from "@/components/KindChip";
import { Button } from "@/components/ui/button";
import { textToDna } from "@/lib/dna";
import { isLocked, type MemoryNode } from "@/lib/nodes";
import { nodeSearchSchema } from "@/lib/search";
import { useBioStore, useNode, useNodes } from "@/lib/store";
import { cn, formatDistance } from "@/lib/utils";

type Phase = "idle" | "sync" | "decode" | "open" | "locked";

export const Route = createFileRoute("/leitor")({
  validateSearch: nodeSearchSchema,
  component: ReaderPage,
});

function ReaderPage() {
  const { node: qNode } = Route.useSearch();
  const nodes = useNodes();
  const selected = useNode(qNode);
  const nearby = [...nodes].sort((a, b) => a.distanceM - b.distanceM);

  if (!selected) {
    return (
      <div className="mx-auto flex max-w-3xl flex-col gap-6">
        <header className="flex flex-col gap-2">
          <p className="text-xs tracking-widest text-subtle uppercase">
            Leitor biológico
          </p>
          <h1 className="font-display text-3xl tracking-tight">
            Aproxime-se de um nó
          </h1>
          <p className="max-w-md text-sm leading-relaxed text-muted">
            O chip de curta distância lê a variação elétrica no toque da folha.
            Escolha uma planta catalogada ao alcance.
          </p>
        </header>
        <ul className="flex flex-col gap-2">
          {nearby.map((node) => (
            <li key={node.id}>
              <Link
                to="/leitor"
                search={{ node: node.id }}
                className="flex items-center gap-3 rounded-[var(--radius-lg)] bg-surface p-2.5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)]"
              >
                <img
                  src={node.image}
                  alt=""
                  className="size-16 rounded-[var(--radius-md)] object-cover outline outline-1 -outline-offset-1 outline-white/10"
                />
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="truncate font-medium">{node.name}</p>
                    <KindChip kind={node.kind} locked={isLocked(node)} />
                  </div>
                  <p className="text-xs text-muted">
                    {node.species} · {formatDistance(node.distanceM)}
                  </p>
                </div>
                <Signal bars={signalBars(node.distanceM)} />
              </Link>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  return <ReaderSession node={selected} />;
}

function signalBars(meters: number): number {
  if (meters < 30) return 4;
  if (meters < 2500) return 3;
  if (meters < 7000) return 2;
  return 1;
}

function Signal({ bars }: { bars: number }) {
  return (
    <span className="flex items-end gap-0.5" aria-label={`${bars} de 4 de sinal`}>
      {[1, 2, 3, 4].map((i) => (
        <span
          key={i}
          className={cn(
            "w-1 rounded-full",
            i <= bars ? "bg-primary" : "bg-border",
          )}
          style={{ height: 6 + i * 3 }}
        />
      ))}
    </span>
  );
}

function ReaderSession({ node }: { node: MemoryNode }) {
  const markRead = useBioStore((s) => s.markRead);
  const locked = isLocked(node);
  const [phase, setPhase] = useState<Phase>("idle");
  const dna = textToDna(node.payload?.title ?? node.name);

  useEffect(() => {
    setPhase("idle");
  }, [node.id]);

  useEffect(() => {
    if (phase !== "sync") return;
    const id = window.setTimeout(() => setPhase("decode"), 1700);
    return () => window.clearTimeout(id);
  }, [phase]);

  useEffect(() => {
    if (phase !== "decode") return;
    const id = window.setTimeout(() => {
      setPhase("open");
      markRead(node.id);
    }, 1600);
    return () => window.clearTimeout(id);
  }, [phase, markRead, node.id]);

  const begin = () => {
    if (locked) {
      setPhase("locked");
      return;
    }
    setPhase("sync");
  };

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-6">
      <Link
        to="/leitor"
        className="inline-flex h-10 w-fit items-center gap-1 text-sm text-muted hover:text-fg"
      >
        <ChevronLeft className="size-4" />
        Outros nós
      </Link>

      <div className="overflow-hidden rounded-[var(--radius-xl)] bg-surface shadow-[var(--shadow-border)]">
        <div className="relative aspect-[16/10] bg-surface-2">
          <img
            src={node.image}
            alt=""
            className="size-full object-cover outline outline-1 -outline-offset-1 outline-white/10"
          />
          <div className="absolute left-3 top-3">
            <KindChip kind={node.kind} locked={locked} />
          </div>
        </div>
        <div className="px-5 py-4">
          <h1 className="font-display text-2xl tracking-tight">{node.name}</h1>
          <p className="mt-1 text-sm text-muted">
            {node.species} · {node.neighborhood}
          </p>
        </div>
      </div>

      <div className="rounded-[var(--radius-xl)] bg-surface p-4 shadow-[var(--shadow-border)]">
        <div className="mb-3 flex items-center justify-between">
          <p className="flex items-center gap-2 text-xs tracking-widest text-subtle uppercase">
            <Radio className="size-3.5" />
            Impulso vegetal
          </p>
          <span className="tab-nums text-xs text-muted">
            {phase === "sync" || phase === "decode" ? "ao vivo" : "em espera"}
          </span>
        </div>
        <EcgCanvas
          running={phase === "sync" || phase === "decode" || phase === "open"}
          intensity={phase === "decode" ? 1.15 : 1}
        />
        {phase === "decode" || phase === "open" ? (
          <div className="mt-3">
            <DnaRibbon dna={dna} />
          </div>
        ) : null}
      </div>

      {phase === "idle" ? (
        <div className="flex flex-col items-center gap-4">
          <HoldLeaf
            onComplete={begin}
            label={
              locked
                ? "Tentar a leitura da cápsula"
                : "Encoste o dedo na folha e mantenha"
            }
          />
          <Button variant="ghost" onClick={begin}>
            Iniciar leitura
          </Button>
        </div>
      ) : null}

      {phase === "sync" ? (
        <p className="text-center text-sm text-muted">
          Sincronizando o micro-sensor da base…
        </p>
      ) : null}

      {phase === "decode" ? (
        <p className="text-center text-sm text-muted">
          Convertendo impulsos em sequência A T C G…
        </p>
      ) : null}

      {phase === "locked" ? (
        <div className="rounded-[var(--radius-xl)] bg-surface px-5 py-6 text-center shadow-[var(--shadow-border)]">
          <Lock className="mx-auto size-6 text-capsule" />
          <h2 className="mt-3 font-display text-2xl">Cápsula selada</h2>
          <p className="mx-auto mt-2 max-w-sm text-sm leading-relaxed text-muted">
            As células replicam o código em silêncio. Este arquivo só germina em{" "}
            {node.unlockYear}.
          </p>
          <Button asChild variant="outline" className="mt-5">
            <Link to="/mapa" search={{ node: node.id }}>
              Voltar ao mapa
            </Link>
          </Button>
        </div>
      ) : null}

      {phase === "open" && node.payload ? <PayloadView node={node} /> : null}
    </div>
  );
}

function PayloadView({ node }: { node: MemoryNode }) {
  const payload = node.payload;
  if (!payload) return null;

  return (
    <article className="rounded-[var(--radius-xl)] bg-surface px-5 py-5 shadow-[var(--shadow-border)]">
      <p className="text-xs tracking-widest text-primary uppercase">
        Arquivo decodificado
      </p>
      <h2 className="mt-2 font-display text-2xl tracking-tight">{payload.title}</h2>
      {payload.type === "image" && payload.mediaSrc ? (
        <img
          src={payload.mediaSrc}
          alt=""
          className="mt-4 w-full rounded-[var(--radius-md)] object-cover outline outline-1 -outline-offset-1 outline-white/10"
        />
      ) : null}
      {payload.type === "audio" ? (
        <PlantVoice duration={payload.durationSec ?? 12} />
      ) : null}
      <p className="mt-4 whitespace-pre-line text-sm leading-relaxed text-muted">
        {payload.body}
      </p>
    </article>
  );
}

function PlantVoice({ duration }: { duration: number }) {
  const [playing, setPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const stopRef = useRef<(() => void) | null>(null);

  useEffect(() => {
    return () => stopRef.current?.();
  }, []);

  const toggle = async () => {
    if (playing) {
      stopRef.current?.();
      stopRef.current = null;
      setPlaying(false);
      return;
    }
    const ctx = new AudioContext();
    await ctx.resume();
    const now = ctx.currentTime;
    const freqs = [110, 164.8, 196, 246.94];
    freqs.forEach((f, i) => {
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = f;
      g.gain.setValueAtTime(0.0001, now);
      g.gain.exponentialRampToValueAtTime(0.045, now + 0.5 + i * 0.12);
      g.gain.exponentialRampToValueAtTime(0.0001, now + duration);
      osc.connect(g).connect(ctx.destination);
      osc.start(now);
      osc.stop(now + duration + 0.05);
    });
    const t0 = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min(1, (t - t0) / (duration * 1000));
      setProgress(p);
      if (p < 1) raf = requestAnimationFrame(tick);
      else {
        setPlaying(false);
        void ctx.close();
        stopRef.current = null;
      }
    };
    raf = requestAnimationFrame(tick);
    stopRef.current = () => {
      cancelAnimationFrame(raf);
      void ctx.close();
      setProgress(0);
    };
    setPlaying(true);
  };

  return (
    <div className="mt-4 flex items-center gap-3 rounded-[var(--radius-md)] bg-bg px-3 py-3">
      <button
        type="button"
        onClick={() => void toggle()}
        className="flex size-11 items-center justify-center rounded-full bg-primary text-primary-fg"
        aria-label={playing ? "Pausar" : "Reproduzir voz da planta"}
      >
        {playing ? (
          <Pause className="size-4" />
        ) : (
          <Play className="size-4 translate-x-px" />
        )}
      </button>
      <div className="flex-1">
        <div className="h-1.5 overflow-hidden rounded-full bg-surface-2">
          <div
            className="h-full rounded-full bg-primary transition-[width] duration-150 ease-linear"
            style={{ width: `${progress * 100}%` }}
          />
        </div>
        <p className="mt-1 text-xs text-muted">Voz vegetal · {duration}s</p>
      </div>
    </div>
  );
}
