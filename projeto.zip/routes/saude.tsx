import { createFileRoute, Link } from "@tanstack/react-router";
import { Droplets, FileText, Image as ImageIcon, Mic } from "lucide-react";
import { toast } from "sonner";
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { KindChip } from "@/components/KindChip";
import { Meter } from "@/components/Meters";
import { Button } from "@/components/ui/button";
import { dayCurve, type ArchiveKind, type MemoryNode } from "@/lib/nodes";
import { nodeSearchSchema } from "@/lib/search";
import { useBioStore, useNode, useNodes } from "@/lib/store";
import { cn, formatBytes, formatClock } from "@/lib/utils";

export const Route = createFileRoute("/saude")({
  validateSearch: nodeSearchSchema,
  component: HealthPage,
});

function HealthPage() {
  const { node: qNode } = Route.useSearch();
  const nodes = useNodes();
  const privateNodes = nodes.filter((n) => n.kind === "private");
  const selected = useNode(qNode) ?? privateNodes[0];
  const water = useBioStore((s) => s.waterPlant);
  const curve = dayCurve();

  if (!selected) return null;

  const needsWater = selected.health.hydration < 45;

  return (
    <div className="mx-auto flex max-w-3xl flex-col gap-6">
      <header>
        <p className="text-xs tracking-widest text-subtle uppercase">
          Saúde da memória
        </p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">
          O que as células replicam
        </h1>
      </header>

      <div className="flex gap-2 overflow-x-auto pb-1">
        {privateNodes.map((n) => (
          <Link
            key={n.id}
            to="/saude"
            search={{ node: n.id }}
            className={cn(
              "flex h-10 shrink-0 items-center gap-2 rounded-full px-3 text-sm transition-[background-color,color] duration-150 ease-out",
              n.id === selected.id
                ? "bg-primary text-primary-fg"
                : "bg-surface text-muted shadow-[var(--shadow-border)]",
            )}
          >
            {n.name.split(" ")[0]}
          </Link>
        ))}
      </div>

      <section className="grid gap-3 sm:grid-cols-[10rem_minmax(0,1fr)]">
        <img
          src={selected.image}
          alt=""
          className="h-40 w-full rounded-[var(--radius-lg)] object-cover sm:h-full outline outline-1 -outline-offset-1 outline-white/10"
        />
        <div className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
          <KindChip kind={selected.kind} />
          <h2 className="mt-2 font-display text-2xl tracking-tight">
            {selected.name}
          </h2>
          <p className="text-sm text-muted">{selected.species}</p>
          <div className="mt-5 flex flex-col gap-3">
            <Meter
              label="Integridade dos dados"
              value={selected.health.integrity}
              tone={selected.health.integrity < 99 ? "warn" : "primary"}
            />
            <Meter
              label="Nível de hidratação"
              value={selected.health.hydration}
              tone={needsWater ? "warn" : "capsule"}
            />
            <Meter
              label="Taxa de fotossíntese"
              value={selected.health.photosynthesis}
              tone="gold"
            />
          </div>
          <Button
            className="mt-5 w-full"
            variant={needsWater ? "primary" : "outline"}
            onClick={() => {
              water(selected.id);
              toast.success(
                `${selected.name} bebeu. O fluxo elétrico estabilizou.`,
              );
            }}
          >
            <Droplets className="size-4" />
            {needsWater ? "Regar agora" : "Regar de novo"}
          </Button>
        </div>
      </section>

      <section className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
        <div className="flex items-baseline justify-between">
          <h3 className="font-display text-xl tracking-tight">
            Velocidade de processamento
          </h3>
          <span className="text-xs text-muted">hoje</span>
        </div>
        <p className="mt-1 text-xs text-muted">
          Fotossíntese ao longo do dia — o relógio biológico do arquivo.
        </p>
        <div className="mt-4 h-44">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={curve} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
              <defs>
                <linearGradient id="photoFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="var(--color-primary)" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="var(--color-primary)" stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="hour"
                tick={{ fill: "var(--color-subtle)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tick={{ fill: "var(--color-subtle)", fontSize: 11 }}
                axisLine={false}
                tickLine={false}
                domain={[0, 100]}
              />
              <Tooltip
                contentStyle={{
                  background: "#12241a",
                  border: "1px solid #234332",
                  borderRadius: 12,
                  color: "#e7f1e8",
                  fontSize: 12,
                }}
                formatter={(v) => [`${v}%`, "Fotossíntese"]}
              />
              <Area
                type="monotone"
                dataKey="value"
                stroke="var(--color-primary)"
                fill="url(#photoFill)"
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="flex flex-col gap-3">
        <h3 className="font-display text-xl tracking-tight">Arquivos neste nó</h3>
        {selected.archives.length === 0 ? (
          <p className="rounded-[var(--radius-lg)] bg-surface px-4 py-6 text-sm text-muted shadow-[var(--shadow-border)]">
            Nenhum arquivo pessoal neste vaso. Grave um no codificador.
          </p>
        ) : (
          selected.archives.map((a) => (
            <article
              key={a.id}
              className="flex items-center gap-3 rounded-[var(--radius-lg)] bg-surface p-3 shadow-[var(--shadow-border)]"
            >
              <ArchiveGlyph kind={a.kind} />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{a.name}</p>
                <p className="text-xs text-muted">
                  {formatBytes(a.sizeBytes)} · {formatClock(a.createdAt)}
                </p>
              </div>
              <span className="tab-nums text-sm text-primary">
                {a.health.toFixed(1).replace(".", ",")}%
              </span>
            </article>
          ))
        )}
      </section>

      <HouseholdStrip nodes={privateNodes} />
    </div>
  );
}

function ArchiveGlyph({ kind }: { kind: ArchiveKind }) {
  const Icon =
    kind === "photo" ? ImageIcon : kind === "voice" ? Mic : FileText;
  return (
    <span className="flex size-11 items-center justify-center rounded-[var(--radius-sm)] bg-bg text-primary">
      <Icon className="size-4" />
    </span>
  );
}

function HouseholdStrip({ nodes }: { nodes: MemoryNode[] }) {
  return (
    <section className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
      <h3 className="font-display text-xl tracking-tight">Casa</h3>
      <ul className="mt-4 flex flex-col gap-4">
        {nodes.map((n) => (
          <li key={n.id} className="flex flex-col gap-2">
            <div className="flex items-center justify-between text-sm">
              <span>{n.name}</span>
              <span className="tab-nums text-muted">
                {n.health.integrity.toFixed(1)}%
              </span>
            </div>
            <Meter label="Integridade" value={n.health.integrity} />
          </li>
        ))}
      </ul>
    </section>
  );
}
