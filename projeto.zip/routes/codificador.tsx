import { useMemo, useState, type ChangeEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { FileText, Image as ImageIcon, Mic, Sprout } from "lucide-react";
import { toast } from "sonner";
import { DnaRibbon } from "@/components/DnaRibbon";
import { KindChip } from "@/components/KindChip";
import { Meter } from "@/components/Meters";
import { Button } from "@/components/ui/button";
import {
  bytesToDna,
  dnaLengthForBytes,
  fileHealthScore,
  textToDna,
} from "@/lib/dna";
import { type ArchiveKind, type MemoryNode } from "@/lib/nodes";
import { useBioStore, useNodes } from "@/lib/store";
import { cn, formatBytes } from "@/lib/utils";

export const Route = createFileRoute("/codificador")({
  component: WriterPage,
});

type Draft = {
  name: string;
  kind: ArchiveKind;
  sizeBytes: number;
  dna: string;
};

const SAMPLES: { name: string; kind: ArchiveKind; text: string }[] = [
  {
    name: "Carta à minha filha.txt",
    kind: "note",
    text: "Guarda isto na samambaia. Se um dia a cidade falhar, a folha ainda sabe o teu nome.",
  },
  {
    name: "Aniversário na varanda.jpg",
    kind: "photo",
    text: "symbiodata:photo:aniversario-varanda:raw-preview",
  },
  {
    name: "Recado da manhã.m4a",
    kind: "voice",
    text: "Não te esqueças de regar. A orquídea está a pedir água desde ontem.",
  },
];

function WriterPage() {
  const nodes = useNodes();
  const encodeArchive = useBioStore((s) => s.encodeArchive);
  const privateNodes = nodes.filter((n) => n.kind === "private");
  const [draft, setDraft] = useState<Draft | null>(null);
  const [plantId, setPlantId] = useState(privateNodes[0]?.id ?? "samambaia");
  const [busy, setBusy] = useState(false);
  const [done, setDone] = useState(false);

  const plant = privateNodes.find((n) => n.id === plantId) ?? privateNodes[0];
  const estimate = plant
    ? fileHealthScore(
        plant.health.integrity,
        plant.health.hydration,
        plant.health.photosynthesis,
      )
    : 0;

  const onFile = async (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const buf = new Uint8Array(await file.slice(0, 256).arrayBuffer());
    const kind: ArchiveKind = file.type.startsWith("audio")
      ? "voice"
      : file.type.startsWith("image")
        ? "photo"
        : file.type.includes("pdf")
          ? "pdf"
          : "note";
    setDone(false);
    setDraft({
      name: file.name,
      kind,
      sizeBytes: file.size,
      dna: bytesToDna(buf),
    });
  };

  const pickSample = (sample: (typeof SAMPLES)[number]) => {
    setDone(false);
    setDraft({
      name: sample.name,
      kind: sample.kind,
      sizeBytes: sample.text.length * 4 + 2400,
      dna: textToDna(sample.text),
    });
  };

  const commit = () => {
    if (!draft || !plant) return;
    setBusy(true);
    window.setTimeout(() => {
      encodeArchive(plant.id, {
        id: `arch-${Date.now()}`,
        name: draft.name,
        kind: draft.kind,
        dnaPreview: draft.dna,
        sizeBytes: draft.sizeBytes,
        createdAt: Date.now(),
        health: estimate,
      });
      setBusy(false);
      setDone(true);
      toast.success(`Arquivo gravado em ${plant.name}.`);
    }, 900);
  };

  return (
    <div className="mx-auto flex max-w-xl flex-col gap-6">
      <header>
        <p className="text-xs tracking-widest text-subtle uppercase">
          Codificador de DNA
        </p>
        <h1 className="mt-1 font-display text-3xl tracking-tight">
          Guardar na planta
        </h1>
        <p className="mt-2 text-sm leading-relaxed text-muted">
          O arquivo é convertido na sequência equivalente (A, T, C, G) e enviado
          ao vaso inteligente — ou a uma bio-impressora local.
        </p>
      </header>

      <div className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-sm font-medium">Escolher um arquivo</p>
        <label className="mt-3 flex cursor-pointer flex-col items-center justify-center rounded-[var(--radius-lg)] bg-bg px-4 py-8 text-center shadow-[var(--shadow-border)]">
          <input type="file" className="sr-only" onChange={(e) => void onFile(e)} />
          <span className="text-sm text-fg">Abrir do telemóvel</span>
          <span className="mt-1 text-xs text-muted">
            PDF, foto ou nota de voz
          </span>
        </label>
        <div className="mt-3 grid gap-2">
          {SAMPLES.map((s) => (
            <button
              key={s.name}
              type="button"
              onClick={() => pickSample(s)}
              className="flex h-12 items-center gap-3 rounded-[var(--radius-md)] px-3 text-left text-sm hover:bg-surface-2"
            >
              <KindIcon kind={s.kind} />
              {s.name}
            </button>
          ))}
        </div>
      </div>

      {draft ? (
        <div className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
          <div className="flex items-start justify-between gap-3">
            <div>
              <p className="text-xs tracking-widest text-subtle uppercase">
                Sequência
              </p>
              <h2 className="mt-1 font-display text-xl leading-snug">{draft.name}</h2>
              <p className="mt-1 text-xs text-muted">
                {formatBytes(draft.sizeBytes)} ·{" "}
                {dnaLengthForBytes(Math.max(draft.sizeBytes, 64)).toLocaleString("pt-BR")}{" "}
                bases
              </p>
            </div>
            <KindIcon kind={draft.kind} />
          </div>
          <div className="mt-4 rounded-[var(--radius-md)] bg-bg p-3">
            <DnaRibbon dna={draft.dna} />
          </div>
        </div>
      ) : null}

      <div className="rounded-[var(--radius-xl)] bg-surface p-5 shadow-[var(--shadow-border)]">
        <p className="text-sm font-medium">Destino</p>
        <div className="mt-3 flex flex-col gap-2">
          {privateNodes.map((n) => (
            <PlantChoice
              key={n.id}
              node={n}
              selected={n.id === plant?.id}
              onSelect={() => setPlantId(n.id)}
            />
          ))}
        </div>
        {plant ? (
          <div className="mt-5 flex flex-col gap-3">
            <Meter
              label="Saúde estimada do arquivo"
              value={estimate}
              tone={estimate < 92 ? "warn" : "primary"}
            />
            <p className="text-xs leading-relaxed text-muted">
              A estimativa depende da hidratação e da luz que {plant.name} está a
              receber. Com o Vaso Inteligente SymbioData a sincronização é
              contínua.
            </p>
          </div>
        ) : null}
      </div>

      <Button
        size="lg"
        disabled={!draft || busy}
        onClick={commit}
        className="w-full"
      >
        {busy ? "Enviando à bio-impressora…" : "Gravar na planta"}
      </Button>

      {done ? (
        <div className="rounded-[var(--radius-xl)] bg-surface px-5 py-5 shadow-[var(--shadow-border)]">
          <Sprout className="size-5 text-primary" />
          <h2 className="mt-2 font-display text-xl">Arquivo a germinar</h2>
          <p className="mt-1 text-sm leading-relaxed text-muted">
            A sequência já replica nas células de {plant?.name}. No plano Pro, o
            kit de vaso inteligente mantém o backup alinhado com a luz do dia.
          </p>
        </div>
      ) : null}
    </div>
  );
}

function KindIcon({ kind }: { kind: ArchiveKind }) {
  const Icon =
    kind === "photo" ? ImageIcon : kind === "voice" ? Mic : FileText;
  return (
    <span className="flex size-9 items-center justify-center rounded-[var(--radius-sm)] bg-surface-2 text-primary">
      <Icon className="size-4" />
    </span>
  );
}

function PlantChoice({
  node,
  selected,
  onSelect,
}: {
  node: MemoryNode;
  selected: boolean;
  onSelect: () => void;
}) {
  const score = useMemo(
    () =>
      fileHealthScore(
        node.health.integrity,
        node.health.hydration,
        node.health.photosynthesis,
      ),
    [node],
  );

  return (
    <button
      type="button"
      onClick={onSelect}
      className={cn(
        "flex items-center gap-3 rounded-[var(--radius-md)] p-2 text-left transition-[box-shadow] duration-150 ease-out",
        selected ? "shadow-[0_0_0_1px_var(--color-primary)]" : "hairline",
      )}
    >
      <img
        src={node.image}
        alt=""
        className="size-12 rounded-[var(--radius-sm)] object-cover outline outline-1 -outline-offset-1 outline-white/10"
      />
      <span className="min-w-0 flex-1">
        <span className="flex items-center gap-2">
          <span className="truncate text-sm font-medium">{node.name}</span>
          <KindChip kind={node.kind} />
        </span>
        <span className="text-xs text-muted">
          Saúde prevista {score.toFixed(1).replace(".", ",")}%
        </span>
      </span>
    </button>
  );
}
