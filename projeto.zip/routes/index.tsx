import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowUpRight, Droplets, SunMedium, X } from "lucide-react";
import { NodeCard } from "@/components/NodeCard";
import { KindChip } from "@/components/KindChip";
import { Meter } from "@/components/Meters";
import { Button } from "@/components/ui/button";
import { isLocked } from "@/lib/nodes";
import { useBioStore, useNodes, useNotices } from "@/lib/store";
import { formatDistance } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const nodes = useNodes();
  const notices = useNotices();
  const dismiss = useBioStore((s) => s.dismissNotice);
  const nearby = [...nodes].sort((a, b) => a.distanceM - b.distanceM);
  const privateNodes = nodes.filter((n) => n.kind === "private");
  const publicCount = nodes.filter((n) => n.kind === "public").length;

  return (
    <div className="stagger-in mx-auto flex max-w-3xl flex-col gap-8">
      <section className="relative overflow-hidden rounded-[var(--radius-xl)] bg-surface px-5 py-6 shadow-[var(--shadow-border)] sm:px-8 sm:py-8">
        <div className="pointer-events-none absolute -right-8 -top-10 size-44 rounded-full bg-primary/10" />
        <div className="pointer-events-none absolute right-10 top-8 size-24 rounded-full border border-primary/25 pulse-ring" />
        <p className="text-xs font-medium tracking-widest text-primary uppercase">
          Rede viva · {publicCount} nós públicos
        </p>
        <h1 className="mt-3 max-w-lg font-display text-[2.15rem] leading-[1.12] font-medium tracking-tight sm:text-5xl">
          A cidade ainda{" "}
          <em className="italic text-primary">respira</em>
          <span className="text-muted">.</span>
        </h1>
        <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
          Aproxime o telemóvel de uma planta catalogada. O toque na folha lê o
          impulso elétrico e devolve o arquivo que a copa replica.
        </p>
        <div className="mt-6 flex flex-wrap gap-2">
          <Button asChild size="lg">
            <Link to="/leitor">Ler uma planta</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link to="/mapa">Abrir o mapa</Link>
          </Button>
        </div>
      </section>

      {notices.length > 0 ? (
        <section className="flex flex-col gap-3">
          <h2 className="text-xs font-medium tracking-widest text-subtle uppercase">
            Avisos da rede
          </h2>
          {notices.map((n) => (
            <article
              key={n.id}
              className="relative rounded-[var(--radius-lg)] bg-surface px-4 py-4 pr-12 shadow-[var(--shadow-border)]"
            >
              <p className="text-[0.6875rem] tracking-wide text-primary uppercase">
                SymbioData · agora
              </p>
              <h3 className="mt-1 font-display text-lg leading-snug">
                {n.title}
              </h3>
              <p className="mt-1 text-sm leading-relaxed text-muted">{n.body}</p>
              <Link
                to="/saude"
                search={{ node: n.nodeId }}
                className="mt-3 inline-flex items-center gap-1 text-sm text-primary"
              >
                Ver saúde <ArrowUpRight className="size-3.5" />
              </Link>
              <button
                type="button"
                onClick={() => dismiss(n.id)}
                className="absolute right-3 top-3 flex size-10 items-center justify-center rounded-[var(--radius-sm)] text-subtle hover:text-fg"
                aria-label="Dispensar aviso"
              >
                <X className="size-4" />
              </button>
            </article>
          ))}
        </section>
      ) : null}

      <section className="flex flex-col gap-4">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-2xl tracking-tight">Nós próximos</h2>
          <Link to="/mapa" className="text-sm text-primary">
            Mapa
          </Link>
        </div>
        <div className="-mx-4 flex snap-x gap-3 overflow-x-auto px-4 pb-1 md:mx-0 md:grid md:grid-cols-3 md:overflow-visible md:px-0">
          {nearby.slice(0, 6).map((node) => (
            <NodeCard key={node.id} node={node} />
          ))}
        </div>
      </section>

      <section className="flex flex-col gap-4">
        <div className="flex items-end justify-between">
          <h2 className="font-display text-2xl tracking-tight">
            Memória doméstica
          </h2>
          <Link to="/saude" className="text-sm text-primary">
            Painel
          </Link>
        </div>
        <div className="flex flex-col gap-3">
          {privateNodes.map((node) => (
            <Link
              key={node.id}
              to="/saude"
              search={{ node: node.id }}
              className="grid grid-cols-[4.5rem_minmax(0,1fr)] gap-3 rounded-[var(--radius-lg)] bg-surface p-2.5 shadow-[var(--shadow-border)] transition-[box-shadow] duration-150 ease-out hover:shadow-[var(--shadow-border-hover)]"
            >
              <img
                src={node.image}
                alt=""
                className="size-[4.5rem] rounded-[var(--radius-md)] object-cover outline outline-1 -outline-offset-1 outline-white/10"
              />
              <div className="flex min-w-0 flex-col justify-center gap-2 pr-2">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <p className="truncate font-medium">{node.name}</p>
                    <p className="text-xs text-muted">
                      {formatDistance(node.distanceM)} · {node.archives.length} arquivo
                      {node.archives.length === 1 ? "" : "s"}
                    </p>
                  </div>
                  <KindChip kind={node.kind} locked={isLocked(node)} />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <span className="flex items-center gap-1.5 text-xs text-muted">
                    <Droplets className="size-3.5 text-capsule" />
                    <span className="tab-nums text-fg">
                      {Math.round(node.health.hydration)}%
                    </span>
                  </span>
                  <span className="flex items-center gap-1.5 text-xs text-muted">
                    <SunMedium className="size-3.5 text-gold" />
                    <span className="tab-nums text-fg">
                      {Math.round(node.health.photosynthesis)}%
                    </span>
                  </span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      <section className="rounded-[var(--radius-xl)] bg-surface px-5 py-5 shadow-[var(--shadow-border)]">
        <p className="text-xs tracking-widest text-subtle uppercase">Integridade média</p>
        <p className="mt-2 font-display text-4xl tracking-tight tab-nums">
          {(
            privateNodes.reduce((a, n) => a + n.health.integrity, 0) /
            Math.max(1, privateNodes.length)
          ).toFixed(1)}
          %
        </p>
        <div className="mt-4">
          <Meter
            label="Replicação celular"
            value={
              privateNodes.reduce((a, n) => a + n.health.integrity, 0) /
              Math.max(1, privateNodes.length)
            }
          />
        </div>
      </section>
    </div>
  );
}
