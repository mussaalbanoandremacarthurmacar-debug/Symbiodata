import { useState } from "react";
import { createFileRoute, Link } from "@tanstack/react-router";
import { Locate, Lock, X } from "lucide-react";
import { BioMap } from "@/components/BioMap";
import { KindChip } from "@/components/KindChip";
import { Button } from "@/components/ui/button";
import { isLocked, type NodeKind } from "@/lib/nodes";
import { nodeSearchSchema } from "@/lib/search";
import { useNode, useNodes } from "@/lib/store";
import { cn, formatDistance } from "@/lib/utils";

type Filter = "all" | NodeKind;

export const Route = createFileRoute("/mapa")({
  validateSearch: nodeSearchSchema,
  component: MapPage,
});

const FILTERS: { id: Filter; label: string }[] = [
  { id: "all", label: "Todos" },
  { id: "public", label: "Públicos" },
  { id: "capsule", label: "Cápsulas" },
  { id: "private", label: "Privados" },
];

function MapPage() {
  const { node: qNode } = Route.useSearch();
  const nodes = useNodes();
  const [filter, setFilter] = useState<Filter>("all");
  const [selectedId, setSelectedId] = useState<string | undefined>(qNode);
  const selected = useNode(selectedId);
  const locked = selected ? isLocked(selected) : false;

  return (
    <section className="relative -mx-4 -mt-2 h-[calc(100dvh-7.25rem)] overflow-hidden rounded-t-[var(--radius-xl)] md:-mx-8 md:-mt-8 md:h-[calc(100dvh-2rem)] md:rounded-[var(--radius-xl)]">
      <BioMap
        nodes={nodes}
        filter={filter}
        selectedId={selectedId}
        onSelect={setSelectedId}
      />

      <div className="pointer-events-none absolute inset-x-0 top-0 z-10 p-3 sm:p-4">
        <div className="pointer-events-auto mx-auto flex max-w-xl flex-col gap-3">
          <div className="rounded-[var(--radius-lg)] bg-bg-raised/95 px-4 py-3 shadow-[var(--shadow-border),var(--shadow-soft)]">
            <p className="text-[0.6875rem] tracking-widest text-subtle uppercase">
              Mapa da rede viva
            </p>
            <h1 className="font-display text-xl tracking-tight">São Paulo</h1>
          </div>
          <div className="flex gap-1.5 overflow-x-auto pb-1">
            {FILTERS.map((f) => (
              <button
                key={f.id}
                type="button"
                onClick={() => setFilter(f.id)}
                className={cn(
                  "h-10 shrink-0 rounded-full px-3.5 text-sm font-medium transition-[background-color,color] duration-150 ease-out",
                  filter === f.id
                    ? "bg-primary text-primary-fg"
                    : "bg-bg-raised/95 text-muted shadow-[var(--shadow-border)]",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-3 right-3 z-10 md:bottom-6 md:right-6">
        <button
          type="button"
          className="flex size-11 items-center justify-center rounded-[var(--radius-md)] bg-surface text-fg shadow-[var(--shadow-border),var(--shadow-soft)]"
          aria-label="Centrar na sua casa"
          onClick={() => setSelectedId("samambaia")}
        >
          <Locate className="size-4" />
        </button>
      </div>

      {selected ? (
        <aside className="absolute inset-x-0 bottom-0 z-20 p-3 sm:p-4">
          <div className="mx-auto flex max-w-xl gap-3 rounded-[var(--radius-xl)] bg-surface p-3 shadow-[var(--shadow-border),var(--shadow-soft)]">
            <img
              src={selected.image}
              alt=""
              className="size-24 shrink-0 rounded-[var(--radius-md)] object-cover outline outline-1 -outline-offset-1 outline-white/10"
            />
            <div className="flex min-w-0 flex-1 flex-col">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <KindChip kind={selected.kind} locked={locked} />
                  <h2 className="mt-1 truncate font-display text-lg leading-tight">
                    {selected.name}
                  </h2>
                  <p className="text-xs text-muted">
                    {selected.neighborhood} · {formatDistance(selected.distanceM)}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedId(undefined)}
                  className="flex size-10 shrink-0 items-center justify-center rounded-[var(--radius-sm)] text-subtle hover:text-fg"
                  aria-label="Fechar"
                >
                  <X className="size-4" />
                </button>
              </div>
              <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-muted">
                {selected.description}
              </p>
              <div className="mt-3">
                {locked ? (
                  <p className="inline-flex items-center gap-1.5 text-sm text-capsule">
                    <Lock className="size-3.5" />
                    Abre em {selected.unlockYear}
                  </p>
                ) : (
                  <Button asChild size="sm">
                    <Link to="/leitor" search={{ node: selected.id }}>
                      Ler este nó
                    </Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </aside>
      ) : null}
    </section>
  );
}
