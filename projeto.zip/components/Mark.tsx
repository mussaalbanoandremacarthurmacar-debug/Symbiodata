import { cn } from "@/lib/utils";

export function Mark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-7 text-primary", className)}
      aria-hidden="true"
    >
      <circle
        cx="16"
        cy="16"
        r="4.2"
        fill="currentColor"
      />
      <path
        d="M16 11.4C16 7.2 12.4 4 8.2 5.1"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <path
        d="M19.2 13.8c4.1-1.6 8.2 1.4 7.4 6.6"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
      <path
        d="M14.2 19.4c-3.8 4.2-1.6 8.6 4.6 8.2"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.6"
        strokeLinecap="round"
      />
    </svg>
  );
}
