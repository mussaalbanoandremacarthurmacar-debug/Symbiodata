import { Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";
import { cn, formatDistance } from "@/lib/utils";
import { isLocked, type MemoryNode } from "@/lib/nodes";
import { KindChip } from "@/components/KindChip";

export function NodeCard({
  node,
  className,
}: {
  node: MemoryNode;
  className?: string;
}) {
  const locked = isLocked(node);

  return (
    <Link
      to="/leitor"
      search={{ node: node.id }}
      className={cn(
        "group relative flex min-w-64 snap-start flex-col overflow-hidden rounded-[var(--radius-xl)] bg-surface text-left shadow-[var(--shadow-border)] transition-[box-shadow,transform] duration-200 ease-out hover:shadow-[var(--shadow-border-hover)]",
        className,
      )}
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-surface-2">
        <img
          src={node.image}
          alt=""
          className="size-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.03] outline outline-1 -outline-offset-1 outline-white/10"
        />
        <div className="absolute inset-x-0 bottom-0 h-24 bg-linear-to-t from-bg/80 to-transparent" />
        <div className="absolute left-3 top-3">
          <KindChip kind={node.kind} locked={locked} />
        </div>
      </div>
      <div className="flex flex-col gap-1 px-4 py-3">
        <h3 className="font-display text-lg font-medium leading-snug tracking-tight">
          {node.name}
        </h3>
        <p className="flex items-center gap-1 text-xs text-muted">
          <MapPin className="size-3" strokeWidth={2} />
          {node.neighborhood} · {formatDistance(node.distanceM)}
        </p>
        {locked ? (
          <p className="mt-1 text-xs text-capsule">Abre em {node.unlockYear}</p>
        ) : null}
      </div>
    </Link>
  );
}
