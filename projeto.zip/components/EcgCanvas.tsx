import { useEffect, useRef } from "react";

function plantSignal(t: number, amp: number): number {
  const breath = Math.sin(t * 0.85) * 0.32;
  const beat = ((t % 1.65) - 0.18) / 0.18;
  const spike = Math.exp(-beat * beat * 14) * 0.92;
  const micro = Math.sin(t * 13.4) * 0.045 + Math.sin(t * 27) * 0.02;
  return (breath + spike + micro) * amp;
}

export function EcgCanvas({
  running,
  intensity = 1,
}: {
  running: boolean;
  intensity?: number;
}) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let raf = 0;
    const t0 = performance.now();
    const history: number[] = [];

    const loop = (now: number) => {
      const t = (now - t0) / 1000;
      const rect = canvas.getBoundingClientRect();
      const dpr = window.devicePixelRatio || 1;
      const width = Math.max(1, Math.floor(rect.width));
      const height = Math.max(1, Math.floor(rect.height));
      if (canvas.width !== width * dpr || canvas.height !== height * dpr) {
        canvas.width = width * dpr;
        canvas.height = height * dpr;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      }

      const amp = running ? intensity : 0.08;
      history.push(plantSignal(t, amp));
      const max = Math.ceil(width);
      if (history.length > max) history.splice(0, history.length - max);

      const styles = getComputedStyle(canvas);
      const glow = styles.getPropertyValue("--color-glow").trim() || "#7dff9a";
      const primary = styles.getPropertyValue("--color-primary").trim() || "#3dba6a";
      const bg = styles.getPropertyValue("--color-bg").trim() || "#07110c";

      ctx.fillStyle = bg;
      ctx.fillRect(0, 0, width, height);

      ctx.strokeStyle = "color-mix(in oklab, var(--color-border) 70%, transparent)";
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, height * 0.55);
      ctx.lineTo(width, height * 0.55);
      ctx.stroke();

      ctx.beginPath();
      for (let i = 0; i < history.length; i += 1) {
        const x = i + (width - history.length);
        const y = height * 0.55 - history[i]! * height * 0.4;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.strokeStyle = glow;
      ctx.lineWidth = 2.2;
      ctx.shadowColor = primary;
      ctx.shadowBlur = running ? 12 : 0;
      ctx.stroke();
      ctx.shadowBlur = 0;

      if (running) {
        const gx = width - 8;
        ctx.fillStyle = glow;
        ctx.beginPath();
        ctx.arc(gx, height * 0.55 - (history[history.length - 1] ?? 0) * height * 0.4, 3, 0, Math.PI * 2);
        ctx.fill();
      }

      raf = requestAnimationFrame(loop);
    };

    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [running, intensity]);

  return (
    <canvas
      ref={ref}
      className="h-36 w-full rounded-[var(--radius-lg)] bg-bg"
      aria-hidden="true"
    />
  );
}
