import { Lock } from "lucide-react";
import { cn } from "@/lib/utils";
import { kindLabel, type NodeKind } from "@/lib/nodes";

export function KindChip({
  kind,
  locked,
  className,
}: {
  kind: NodeKind;
  locked?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "inline-flex h-7 items-center gap-1.5 rounded-full px-2.5 text-[0.6875rem] font-medium tracking-wide",
        kind === "public" && "bg-primary/15 text-primary",
        kind === "capsule" && "bg-capsule/15 text-capsule",
        kind === "private" && "bg-gold/15 text-gold",
        className,
      )}
    >
      <span
        className={cn(
          "size-1.5 rounded-full",
          kind === "public" && "bg-primary",
          kind === "capsule" && "bg-capsule",
          kind === "private" && "bg-gold",
        )}
      />
      {locked ? <Lock className="size-3" strokeWidth={2} /> : null}
      {kindLabel(kind)}
    </span>
  );
}
