import { useEffect, useRef, useState } from "react";
import { HOME, isLocked, type MemoryNode, type NodeKind } from "@/lib/nodes";
import "leaflet/dist/leaflet.css";

type Filter = "all" | NodeKind;

export function BioMap({
  nodes,
  filter,
  selectedId,
  onSelect,
}: {
  nodes: MemoryNode[];
  filter: Filter;
  selectedId?: string;
  onSelect: (id: string) => void;
}) {
  const host = useRef<HTMLDivElement>(null);
  const mapRef = useRef<import("leaflet").Map | null>(null);
  const groupRef = useRef<import("leaflet").LayerGroup | null>(null);
  const leafletRef = useRef<typeof import("leaflet") | null>(null);
  const selectRef = useRef(onSelect);
  const [ready, setReady] = useState(false);
  selectRef.current = onSelect;

  useEffect(() => {
    let cancelled = false;
    const el = host.current;
    if (!el) return;

    (async () => {
      const leaflet = await import("leaflet");
      if (cancelled || mapRef.current || !host.current) return;
      const L = leaflet.default ?? leaflet;
      leafletRef.current = L;
      const map = L.map(host.current, {
        zoomControl: false,
        attributionControl: true,
      }).setView([HOME.lat, HOME.lng], 13);
      L.tileLayer(
        "https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png",
        {
          attribution: "&copy; OpenStreetMap &copy; CARTO",
          maxZoom: 19,
        },
      ).addTo(map);
      L.control.zoom({ position: "bottomright" }).addTo(map);
      groupRef.current = L.layerGroup().addTo(map);
      mapRef.current = map;
      setReady(true);
      window.setTimeout(() => map.invalidateSize(), 60);
    })();

    return () => {
      cancelled = true;
      mapRef.current?.remove();
      mapRef.current = null;
      groupRef.current = null;
      setReady(false);
    };
  }, []);

  useEffect(() => {
    const L = leafletRef.current;
    const map = mapRef.current;
    const group = groupRef.current;
    if (!ready || !L || !map || !group) return;

    group.clearLayers();

    const you = L.divIcon({
      className: "",
      html: `<div class="you-pin"></div>`,
      iconSize: [12, 12],
      iconAnchor: [6, 6],
    });
    L.marker([HOME.lat, HOME.lng], { icon: you, interactive: false }).addTo(group);

    const visible = nodes.filter((n) => filter === "all" || n.kind === filter);
    for (const node of visible) {
      const locked = isLocked(node);
      const active = node.id === selectedId;
      const icon = L.divIcon({
        className: "",
        html: `<div class="node-pin is-${node.kind}${locked ? " is-locked" : ""}${active ? " is-active" : ""}"></div>`,
        iconSize: [22, 22],
        iconAnchor: [11, 11],
      });
      L.marker([node.lat, node.lng], { icon })
        .on("click", () => selectRef.current(node.id))
        .addTo(group);
    }

    if (selectedId) {
      const n = nodes.find((x) => x.id === selectedId);
      if (n) map.panTo([n.lat, n.lng], { animate: true });
    }
  }, [nodes, filter, selectedId, ready]);

  return <div ref={host} className="absolute inset-0 z-0" />;
}
