import { cn } from "@/lib/utils";

export function Meter({
  label,
  value,
  max = 100,
  suffix = "%",
  tone = "primary",
}: {
  label: string;
  value: number;
  max?: number;
  suffix?: string;
  tone?: "primary" | "warn" | "gold" | "capsule";
}) {
  const pct = Math.max(0, Math.min(100, (value / max) * 100));
  const rounded = Math.round(value);
  const display =
    suffix === "%"
      ? `${Math.abs(value - rounded) < 0.05 ? String(rounded) : value.toFixed(1).replace(".", ",")}${suffix}`
      : `${value.toFixed(1).replace(".", ",")}${suffix}`;

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-baseline justify-between gap-3">
        <span className="text-xs text-muted">{label}</span>
        <span className="tab-nums text-xs font-medium text-fg">{display}</span>
      </div>
      <div className="h-1.5 overflow-hidden rounded-full bg-bg">
        <div
          className={cn(
            "h-full rounded-full transition-[width] duration-500 ease-out",
            tone === "primary" && "bg-primary",
            tone === "warn" && "bg-warn",
            tone === "gold" && "bg-gold",
            tone === "capsule" && "bg-capsule",
          )}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
