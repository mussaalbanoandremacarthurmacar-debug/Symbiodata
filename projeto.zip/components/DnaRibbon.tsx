import { cn } from "@/lib/utils";

export function DnaRibbon({
  dna,
  className,
}: {
  dna: string;
  className?: string;
}) {
  const slice = dna.slice(0, 220);
  return (
    <p
      className={cn(
        "break-all font-mono text-[0.7rem] leading-relaxed tracking-wider",
        className,
      )}
      aria-label="Sequência genética"
    >
      {slice.split("").map((base, i) => (
        <span
          key={`${base}-${i}`}
          className={cn(
            base === "A" && "dna-base-a",
            base === "C" && "dna-base-c",
            base === "G" && "dna-base-g",
            base === "T" && "dna-base-t",
          )}
        >
          {base}
          {(i + 1) % 4 === 0 ? " " : ""}
        </span>
      ))}
      {dna.length > 220 ? "…" : ""}
    </p>
  );
}
