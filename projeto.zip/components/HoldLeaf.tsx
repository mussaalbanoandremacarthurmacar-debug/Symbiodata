import { useEffect, useRef, useState } from "react";
import { Leaf } from "lucide-react";
import { cn } from "@/lib/utils";

const HOLD_MS = 1350;

export function HoldLeaf({
  onComplete,
  disabled,
  label = "Encoste o dedo na folha",
}: {
  onComplete: () => void;
  disabled?: boolean;
  label?: string;
}) {
  const [holding, setHolding] = useState(false);
  const timer = useRef<number | null>(null);
  const reduce = useRef(false);

  useEffect(() => {
    reduce.current = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  }, []);

  const clear = () => {
    if (timer.current) window.clearTimeout(timer.current);
    timer.current = null;
    setHolding(false);
  };

  const start = () => {
    if (disabled) return;
    if (reduce.current) {
      onComplete();
      return;
    }
    setHolding(true);
    timer.current = window.setTimeout(() => {
      timer.current = null;
      setHolding(false);
      onComplete();
    }, HOLD_MS);
  };

  useEffect(() => () => clear(), []);

  return (
    <div className="flex flex-col items-center gap-3">
      <button
        type="button"
        disabled={disabled}
        onPointerDown={start}
        onPointerUp={clear}
        onPointerLeave={clear}
        onPointerCancel={clear}
        className={cn(
          "relative flex size-28 items-center justify-center rounded-organic bg-primary text-primary-fg shadow-[var(--shadow-soft)] transition-[scale,opacity] duration-150 ease-out",
          "active:scale-[0.96] disabled:opacity-40",
          holding && "opacity-95",
        )}
        aria-label={label}
      >
        <span
          className="absolute inset-0 overflow-hidden rounded-organic"
          aria-hidden="true"
        >
          <span
            className={cn(
              "absolute inset-x-0 bottom-0 bg-glow/35",
              holding ? "hold-fill origin-bottom h-full" : "h-0",
            )}
            style={{ transformOrigin: "bottom" }}
          />
        </span>
        <Leaf className="relative size-9" strokeWidth={1.6} />
      </button>
      <p className="text-center text-sm text-muted">{label}</p>
    </div>
  );
}
