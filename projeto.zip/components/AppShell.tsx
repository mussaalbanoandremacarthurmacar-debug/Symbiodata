import { useEffect, type ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Activity, Dna, HeartPulse, Leaf, Map } from "lucide-react";
import { Toaster } from "sonner";
import { cn } from "@/lib/utils";
import { useBioStore } from "@/lib/store";
import { Mark } from "@/components/Mark";

const NAV = [
  { to: "/", label: "Rede", icon: Leaf, featured: false },
  { to: "/mapa", label: "Mapa", icon: Map, featured: false },
  { to: "/leitor", label: "Ler", icon: Activity, featured: true },
  { to: "/codificador", label: "Gravar", icon: Dna, featured: false },
  { to: "/saude", label: "Saúde", icon: HeartPulse, featured: false },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const tick = useBioStore((s) => s.tick);

  useEffect(() => {
    tick();
    const id = window.setInterval(tick, 20000);
    return () => window.clearInterval(id);
  }, [tick]);

  return (
    <div className="vein-field min-h-dvh">
      <div className="mx-auto flex min-h-dvh w-full max-w-6xl md:grid md:grid-cols-[15.5rem_minmax(0,1fr)]">
        <aside className="hidden flex-col gap-8 border-r border-border/80 px-5 py-8 md:flex">
          <BrandLockup />
          <nav className="flex flex-1 flex-col gap-1" aria-label="Principal">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.to);
              const Icon = item.icon;
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-[var(--radius-md)] px-3 text-sm font-medium transition-[background-color,color] duration-150 ease-out",
                    active
                      ? "bg-surface-2 text-fg"
                      : "text-muted hover:bg-surface hover:text-fg",
                  )}
                >
                  <Icon className="size-4" strokeWidth={1.75} />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <p className="text-xs leading-relaxed text-subtle">
            Rede viva · São Paulo
          </p>
        </aside>

        <div className="relative flex min-h-dvh min-w-0 flex-col">
          <header className="flex items-center justify-between px-5 pt-[max(1rem,env(safe-area-inset-top))] pb-2 md:hidden">
            <BrandLockup compact />
            <span className="text-[0.6875rem] tracking-wide text-subtle uppercase">
              SP
            </span>
          </header>
          <main className="min-w-0 flex-1 px-4 pb-28 md:px-8 md:pb-10 md:pt-8">
            {children}
          </main>
        </div>
      </div>

      <nav
        aria-label="Principal"
        className="fixed inset-x-0 bottom-0 z-40 px-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:hidden"
      >
        <div className="mx-auto flex max-w-lg items-end justify-between gap-1 rounded-[1.75rem] bg-surface px-2 py-2 shadow-[var(--shadow-border),var(--shadow-soft)]">
          {NAV.map((item) => {
            const active =
              item.to === "/"
                ? pathname === "/"
                : pathname.startsWith(item.to);
            const Icon = item.icon;
            if (item.featured) {
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex size-14 shrink-0 flex-col items-center justify-center rounded-[1.35rem] bg-primary text-primary-fg transition-[scale,opacity] duration-150 ease-out active:scale-[0.96]",
                    active ? "opacity-100" : "opacity-95",
                  )}
                  aria-current={active ? "page" : undefined}
                >
                  <Icon className="size-5" strokeWidth={2} />
                  <span className="sr-only">{item.label}</span>
                </Link>
              );
            }
            return (
              <Link
                key={item.to}
                to={item.to}
                className={cn(
                  "flex h-12 min-w-12 flex-1 flex-col items-center justify-center gap-0.5 rounded-[var(--radius-md)] text-[0.625rem] font-medium transition-[color,background-color] duration-150 ease-out",
                  active ? "text-fg" : "text-subtle",
                )}
                aria-current={active ? "page" : undefined}
              >
                <Icon className="size-4" strokeWidth={1.75} />
                {item.label}
              </Link>
            );
          })}
        </div>
      </nav>

      <Toaster
        theme="dark"
        position="top-center"
        toastOptions={{
          style: {
            background: "#12241a",
            border: "1px solid #234332",
            color: "#e7f1e8",
            fontFamily: "Outfit, sans-serif",
          },
        }}
      />
    </div>
  );
}

function BrandLockup({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5 text-fg">
      <Mark />
      <span className="leading-tight">
        <span className="block font-display text-base font-medium tracking-tight">
          SymbioData
        </span>
        {compact ? null : (
          <span className="block text-[0.6875rem] text-muted">
            Conecte-se à rede viva.
          </span>
        )}
      </span>
    </Link>
  );
}
