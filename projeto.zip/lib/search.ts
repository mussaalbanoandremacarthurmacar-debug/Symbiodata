import { z } from "zod";

export const nodeSearchSchema = z.object({
  node: z.string().optional(),
});

export type NodeSearch = z.infer<typeof nodeSearchSchema>;
