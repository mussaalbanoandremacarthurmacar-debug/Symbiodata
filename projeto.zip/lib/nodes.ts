import { textToDna } from "@/lib/dna";

export type NodeKind = "public" | "capsule" | "private";
export type PayloadType = "text" | "image" | "audio";
export type ArchiveKind = "pdf" | "photo" | "voice" | "note";

export type PlantHealth = {
  integrity: number;
  hydration: number;
  photosynthesis: number;
};

export type MemoryPayload = {
  type: PayloadType;
  title: string;
  body: string;
  mediaSrc?: string;
  durationSec?: number;
};

export type Archive = {
  id: string;
  name: string;
  kind: ArchiveKind;
  dnaPreview: string;
  sizeBytes: number;
  createdAt: number;
  health: number;
};

export type MemoryNode = {
  id: string;
  name: string;
  species: string;
  kind: NodeKind;
  lat: number;
  lng: number;
  neighborhood: string;
  city: string;
  distanceM: number;
  description: string;
  unlockYear?: number;
  image: string;
  health: PlantHealth;
  payload: MemoryPayload | null;
  archives: Archive[];
};

export const HOME = { lat: -23.5466, lng: -46.691, label: "Vila Madalena" };

export const SEED_NODES: MemoryNode[] = [
  {
    id: "figueira",
    name: "Figueira do Ibirapuera",
    species: "Ficus organensis",
    kind: "public",
    lat: -23.5874,
    lng: -46.6576,
    neighborhood: "Parque Ibirapuera",
    city: "São Paulo",
    distanceM: 5600,
    description:
      "Árvore de memória pública. Guarda a história oral do parque e um arquivo fotográfico de 1954, aberto a qualquer leitor.",
    image: "/plants/figueira.jpg",
    health: { integrity: 99.7, hydration: 74, photosynthesis: 81 },
    payload: {
      type: "image",
      title: "Domingo de 1954",
      body: "Em agosto de 1954, famílias inteiras estendiam cangas sob esta figueira. O lago ainda cheirava a terra nova e o parque era promessa. A copa guardou as vozes — brincadeiras, rádios de válvula, o nome de quem plantou a muda. Toque a folha para devolver o dia à luz.",
      mediaSrc: "/memories/ibirapuera-1954.jpg",
    },
    archives: [],
  },
  {
    id: "ipe",
    name: "Ipê da Paulista",
    species: "Handroanthus albus",
    kind: "public",
    lat: -23.5614,
    lng: -46.656,
    neighborhood: "Avenida Paulista",
    city: "São Paulo",
    distanceM: 3800,
    description:
      "Ponto público de leitura livre. No florescimento, a copa libera um livro comunitário — crónicas do bairro, sem fechadura.",
    image: "/plants/ipe.jpg",
    health: { integrity: 99.4, hydration: 58, photosynthesis: 88 },
    payload: {
      type: "text",
      title: "Biblioteca-folha",
      body: "Quando o ipê dourado abre, a avenida inteira lê. Guarda um caderno coletivo: o padeiro que abria às quatro, a professora que atravessava o minhocão, o menino que colecionava sementes no canteiro. Não há capa, nem editora. Só a copa, e o que a cidade quis não esquecer.\n\n«A memória não pesa. Pesa o silêncio de quem não a planta.»\n\n— Caderno aberto da Paulista, edição contínua.",
    },
    archives: [],
  },
  {
    id: "jequitiba",
    name: "Jequitibá da República",
    species: "Cariniana legalis",
    kind: "public",
    lat: -23.5436,
    lng: -46.6425,
    neighborhood: "Praça da República",
    city: "São Paulo",
    distanceM: 5100,
    description:
      "Nó público de áudio. O tronco replica depoimentos de quem atravessou a praça em sete décadas — um ecocardiograma de vozes.",
    image: "/plants/jequitiba.jpg",
    health: { integrity: 99.2, hydration: 66, photosynthesis: 73 },
    payload: {
      type: "audio",
      title: "Vozes da República",
      body: "«Eu vendia jambu aqui em 71. O jequitibá já era velho. A gente encostava as caixas na sombra e o rádio falava de eleição. Se a árvore guarda conversa, então ela sabe o nome de todo mundo que passou com pressa.»\n\nDepoimento de Helena M., feirante. Gravado na base do tronco, 2019.",
      durationSec: 18,
    },
    archives: [],
  },
  {
    id: "palmeira",
    name: "Palmeira Imperial",
    species: "Roystonea oleracea",
    kind: "capsule",
    lat: -23.639,
    lng: -46.6225,
    neighborhood: "Jardim Botânico",
    city: "São Paulo",
    distanceM: 12400,
    description:
      "Cápsula do tempo. O arquivo foi escrito nas células em 2022 e só germina no ano gravado — 2030.",
    unlockYear: 2030,
    image: "/plants/palmeira.jpg",
    health: { integrity: 99.9, hydration: 71, photosynthesis: 69 },
    payload: {
      type: "text",
      title: "Carta selada",
      body: "Este arquivo ainda dorme. As células replicam o código em silêncio até 2030.",
    },
    archives: [],
  },
  {
    id: "pau-brasil",
    name: "Pau-Brasil da Luz",
    species: "Paubrasilia echinata",
    kind: "capsule",
    lat: -23.5332,
    lng: -46.6322,
    neighborhood: "Parque da Luz",
    city: "São Paulo",
    distanceM: 6200,
    description:
      "Cápsula do tempo aberta em 2026. Uma carta plantada dez anos antes, agora legível.",
    unlockYear: 2026,
    image: "/plants/pau-brasil.jpg",
    health: { integrity: 99.6, hydration: 63, photosynthesis: 77 },
    payload: {
      type: "text",
      title: "Carta à cidade futura",
      body: "São Paulo, 2016.\n\nSe estás a ler isto, a cidade ainda respira. Plantámos esta carta no pau-brasil porque o papel amarela e o disco rígido falha, mas a árvore insiste. Queríamos que soubesses: no ano em que escrevemos, a Luz ainda tinha o mesmo banco de pedra e o mesmo cheiro de terra molhada depois da chuva de novembro.\n\nNão pedimos que a cidade seja a mesma. Pedimos que continue viva.\n\n— Um jardineiro, uma arquivista, uma criança que escolheu a muda.",
    },
    archives: [],
  },
  {
    id: "samambaia",
    name: "Samambaia da Sala",
    species: "Nephrolepis exaltata",
    kind: "private",
    lat: -23.5466,
    lng: -46.691,
    neighborhood: "Vila Madalena",
    city: "São Paulo",
    distanceM: 4,
    description:
      "Nó privado no vaso inteligente da sala. Replica o backup de fotos pessoais com integridade plena.",
    image: "/plants/samambaia.jpg",
    health: { integrity: 99.9, hydration: 82, photosynthesis: 94 },
    payload: {
      type: "image",
      title: "Backup de fotos pessoais",
      body: "Álbum doméstico replicado nas frondes. Luz de hoje suficiente — sincronização completa.",
      mediaSrc: "/plants/samambaia.jpg",
    },
    archives: [
      {
        id: "arch-fotos",
        name: "Backup de fotos pessoais",
        kind: "photo",
        dnaPreview: textToDna("symbiodata:album-fotos-pessoais:v1"),
        sizeBytes: 48_200_000,
        createdAt: Date.now() - 86400000 * 12,
        health: 100,
      },
    ],
  },
  {
    id: "monstera",
    name: "Costela-de-Adão",
    species: "Monstera deliciosa",
    kind: "private",
    lat: -23.566,
    lng: -46.682,
    neighborhood: "Pinheiros",
    city: "São Paulo",
    distanceM: 2300,
    description:
      "Nó privado no ateliê. Guarda notas de voz e cadernos que não devem sair de casa.",
    image: "/plants/monstera.jpg",
    health: { integrity: 99.1, hydration: 61, photosynthesis: 70 },
    payload: {
      type: "audio",
      title: "Notas de voz do ateliê",
      body: "«Lembra o amarelo da parede antes da chuva. Não filmes — só a voz chega.»\n\nTrês notas curtas, gravadas à noite, quando a folha conduz melhor.",
      durationSec: 12,
    },
    archives: [
      {
        id: "arch-voice",
        name: "Notas de voz do ateliê",
        kind: "voice",
        dnaPreview: textToDna("symbiodata:voice-notes-atelie:v1"),
        sizeBytes: 3_400_000,
        createdAt: Date.now() - 86400000 * 4,
        health: 97.4,
      },
    ],
  },
  {
    id: "orquidea",
    name: "Orquídea da Varanda",
    species: "Phalaenopsis amabilis",
    kind: "private",
    lat: -23.546,
    lng: -46.69,
    neighborhood: "Vila Madalena",
    city: "São Paulo",
    distanceM: 18,
    description:
      "Nó privado na varanda. Documentos pessoais. A hidratação está baixa — o fluxo de leitura pode oscilar.",
    image: "/plants/orquidea.jpg",
    health: { integrity: 98.6, hydration: 28, photosynthesis: 54 },
    payload: {
      type: "text",
      title: "Pasta de documentos",
      body: "Contratos, cartas e um testamento vegetal: nomes, datas, a chave do arquivo morto. A orquídea replica devagar quando a terra seca. Regue para manter a integridade acima de 99%.",
    },
    archives: [
      {
        id: "arch-docs",
        name: "Documentos da varanda",
        kind: "pdf",
        dnaPreview: textToDna("symbiodata:docs-varanda:v1"),
        sizeBytes: 1_120_000,
        createdAt: Date.now() - 86400000 * 21,
        health: 91.2,
      },
    ],
  },
];

export function isLocked(node: MemoryNode): boolean {
  if (node.kind !== "capsule" || node.unlockYear == null) return false;
  return new Date().getFullYear() < node.unlockYear;
}

export function kindLabel(kind: NodeKind): string {
  if (kind === "public") return "Público";
  if (kind === "capsule") return "Cápsula";
  return "Privado";
}

export function photosynthesisForHour(hour: number, base: number): number {
  const daylight = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
  return Math.round(Math.min(99, base * 0.28 + daylight * 72));
}

export function dayCurve(now = new Date()): { hour: string; value: number }[] {
  const h = now.getHours() + now.getMinutes() / 60;
  const points: { hour: string; value: number }[] = [];
  for (let i = 0; i <= 12; i += 1) {
    const hour = i + 6;
    const label = `${String(hour).padStart(2, "0")}h`;
    const daylight = Math.max(0, Math.sin(((hour - 6) / 12) * Math.PI));
    const noise = hour <= h ? Math.sin(hour * 1.7) * 3 : 0;
    points.push({
      hour: label,
      value: hour <= h + 0.01 ? Math.round(18 + daylight * 74 + noise) : 0,
    });
  }
  return points;
}
