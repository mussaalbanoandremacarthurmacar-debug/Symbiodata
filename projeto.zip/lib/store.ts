import { useMemo } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import { fileHealthScore } from "@/lib/dna";
import {
  SEED_NODES,
  photosynthesisForHour,
  type Archive,
  type MemoryNode,
  type PlantHealth,
} from "@/lib/nodes";

export type Notice = {
  id: string;
  nodeId: string;
  title: string;
  body: string;
  fresh: boolean;
};

type HealthMap = Record<string, PlantHealth>;
type ArchiveMap = Record<string, Archive[]>;

function seedHealth(): HealthMap {
  const map: HealthMap = {};
  for (const n of SEED_NODES) map[n.id] = { ...n.health };
  return map;
}

function seedArchives(): ArchiveMap {
  const map: ArchiveMap = {};
  for (const n of SEED_NODES) map[n.id] = n.archives.map((a) => ({ ...a }));
  return map;
}

const SEED_NOTICES: Notice[] = [
  {
    id: "fern-sync",
    nodeId: "samambaia",
    title: "Samambaia da Sala",
    body: "Absorveu luz suficiente hoje. O seu backup de fotos pessoais está 100% sincronizado e saudável.",
    fresh: true,
  },
  {
    id: "orchid-water",
    nodeId: "orquidea",
    title: "Orquídea da Varanda",
    body: "A hidratação caiu para 28%. O fluxo elétrico de leitura pode oscilar até a planta beber.",
    fresh: true,
  },
];

type AppState = {
  healthById: HealthMap;
  archivesById: ArchiveMap;
  readIds: string[];
  dismissed: string[];
  encodeArchive: (plantId: string, archive: Archive) => void;
  waterPlant: (plantId: string) => void;
  markRead: (plantId: string) => void;
  dismissNotice: (id: string) => void;
  tick: () => void;
};

export const useBioStore = create<AppState>()(
  persist(
    (set, get) => ({
      healthById: seedHealth(),
      archivesById: seedArchives(),
      readIds: [],
      dismissed: [],
      encodeArchive: (plantId, archive) => {
        const archives = get().archivesById[plantId] ?? [];
        const health = get().healthById[plantId];
        const scored: Archive = {
          ...archive,
          health: health
            ? fileHealthScore(
                health.integrity,
                health.hydration,
                health.photosynthesis,
              )
            : archive.health,
        };
        set({
          archivesById: {
            ...get().archivesById,
            [plantId]: [scored, ...archives],
          },
        });
      },
      waterPlant: (plantId) => {
        const seed = SEED_NODES.find((n) => n.id === plantId);
        const current = get().healthById[plantId] ?? seed?.health;
        if (!current) return;
        const integrity = Math.min(99.9, current.integrity + 0.4);
        set({
          healthById: {
            ...get().healthById,
            [plantId]: {
              ...current,
              hydration: Math.min(96, Math.max(current.hydration, 36) + 40),
              integrity,
            },
          },
        });
      },
      markRead: (plantId) => {
        if (get().readIds.includes(plantId)) return;
        set({ readIds: [...get().readIds, plantId] });
      },
      dismissNotice: (id) => {
        if (get().dismissed.includes(id)) return;
        set({ dismissed: [...get().dismissed, id] });
      },
      tick: () => {
        const hour = new Date().getHours() + new Date().getMinutes() / 60;
        const next: HealthMap = { ...get().healthById };
        for (const n of SEED_NODES) {
          const h = next[n.id] ?? n.health;
          const photo = photosynthesisForHour(hour, n.health.photosynthesis);
          const hydration = Math.max(12, h.hydration - 0.04);
          const integrity =
            hydration < 35
              ? Math.max(96.2, h.integrity - 0.01)
              : Math.min(99.9, h.integrity + 0.004);
          next[n.id] = { ...h, photosynthesis: photo, hydration, integrity };
        }
        set({ healthById: next });
      },
    }),
    {
      name: "symbiodata-v1",
      partialize: (s) => ({
        healthById: s.healthById,
        archivesById: s.archivesById,
        readIds: s.readIds,
        dismissed: s.dismissed,
      }),
      merge: (persisted, current) => {
        const p = (persisted ?? {}) as Partial<AppState>;
        return {
          ...current,
          ...p,
          healthById: { ...current.healthById, ...p.healthById },
          archivesById: { ...current.archivesById, ...p.archivesById },
          readIds: p.readIds ?? current.readIds,
          dismissed: p.dismissed ?? current.dismissed,
        };
      },
    },
  ),
);

export function hydrateNode(seed: MemoryNode): MemoryNode {
  const health = useBioStore.getState().healthById[seed.id] ?? seed.health;
  const archives = useBioStore.getState().archivesById[seed.id] ?? seed.archives;
  return { ...seed, health, archives };
}

export function useNodes(): MemoryNode[] {
  const healthById = useBioStore((s) => s.healthById);
  const archivesById = useBioStore((s) => s.archivesById);
  return useMemo(
    () =>
      SEED_NODES.map((n) => ({
        ...n,
        health: healthById[n.id] ?? n.health,
        archives: archivesById[n.id] ?? n.archives,
      })),
    [healthById, archivesById],
  );
}

export function useNode(id: string | undefined): MemoryNode | undefined {
  const nodes = useNodes();
  if (!id) return undefined;
  return nodes.find((n) => n.id === id);
}

export function useNotices(): Notice[] {
  const dismissed = useBioStore((s) => s.dismissed);
  const healthById = useBioStore((s) => s.healthById);
  return SEED_NOTICES.filter((n) => !dismissed.includes(n.id)).filter((n) => {
    if (n.id === "orchid-water") {
      const h = healthById.orquidea;
      return !h || h.hydration < 45;
    }
    return true;
  });
}
