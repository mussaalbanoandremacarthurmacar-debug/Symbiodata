const BASES = ["A", "C", "G", "T"] as const;
export type DnaBase = (typeof BASES)[number];

export function bytesToDna(bytes: Uint8Array): string {
  let out = "";
  for (const b of bytes) {
    out += BASES[(b >> 6) & 3];
    out += BASES[(b >> 4) & 3];
    out += BASES[(b >> 2) & 3];
    out += BASES[b & 3];
  }
  return out;
}

export function textToDna(text: string): string {
  return bytesToDna(new TextEncoder().encode(text));
}

export function dnaCounts(dna: string): Record<DnaBase, number> {
  const counts: Record<DnaBase, number> = { A: 0, C: 0, G: 0, T: 0 };
  for (const c of dna) {
    if (c === "A" || c === "C" || c === "G" || c === "T") counts[c] += 1;
  }
  return counts;
}

export function formatDna(dna: string, group = 4): string {
  const chunks = dna.match(new RegExp(`.{1,${group}}`, "g"));
  return chunks ? chunks.join(" ") : dna;
}

export function dnaLengthForBytes(byteLength: number): number {
  return byteLength * 4;
}

export function fileHealthScore(
  integrity: number,
  hydration: number,
  photosynthesis: number,
): number {
  const h =
    (integrity / 100) *
    (0.5 + 0.5 * (hydration / 100)) *
    (0.72 + 0.28 * (photosynthesis / 100));
  return Math.max(0, Math.min(100, Math.round(h * 1000) / 10));
}
